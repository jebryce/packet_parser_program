# I do not know a different way of doing this, this should be replaced
import pathlib

PATH = str(pathlib.Path.home()) + '/Documents/PPP/'

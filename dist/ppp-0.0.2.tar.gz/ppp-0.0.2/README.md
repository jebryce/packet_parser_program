# Packet Parser Program (PPP)
A Python based network packet analyzer/parser used in the SCADA lab at the University of Hawaii at Manoa.

See control.py for my testing control setup.